declare module 'number-abbreviate';
